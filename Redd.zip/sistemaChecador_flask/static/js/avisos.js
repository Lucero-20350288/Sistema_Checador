// Get the modal
var modalTrabajador = document.getElementById('modalTrabajador');
var modalGeneral = document.getElementById('modalGeneral');

// Get the button that opens the modal
var btnTrabajador = document.getElementById("btnAvisoTrabajador");
var btnGeneral = document.getElementById("btnAvisoGeneral");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close");

// When the user clicks the button, open the modal 
btnTrabajador.onclick = function() {
    modalTrabajador.style.display = "block";
}
btnGeneral.onclick = function() {
    modalGeneral.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
for (var i = 0; i < span.length; i++) {
    span[i].onclick = function() {
        this.parentElement.parentElement.style.display = "none";
    }
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modalTrabajador) {
        modalTrabajador.style.display = "none";
    } else if (event.target == modalGeneral) {
        modalGeneral.style.display = "none";
    }
}
