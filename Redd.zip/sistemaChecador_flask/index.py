from flask import Flask, render_template, request, Response, jsonify, redirect, url_for,make_response
import database as dbase
from flask import send_file
from empleado import Empleado
from datetime import datetime,timedelta
import pandas as pd
from pandas import DataFrame
from openpyxl import Workbook
from io import BytesIO
import pdfkit
import pytz
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Border, Side, Alignment, PatternFill
import platform
import subprocess




db = dbase.dbConnection()

app = Flask(__name__)

#Rutas de la aplicacion



#ALIOTH RUTAS :)

#Frame con el que se despliega reportes de horario, principal en catalogo-horario- despliega esto...
#Estas rutas se llaman en la parte de index.html o tambien en otros template dependiendo el caso... en este caso 
#solo devuelve la plantilla de horarios.html pero tambien puede hacer una solicitud get o post o etc...
@app.route('/framehorario')
def framehorario():
  return render_template('horarios.html') 

@app.route('/framehorarioEmpleados')
def framehorarioEmpleados():
  return render_template('horarioempleados.html') 




#FINALIZA ROUTES ALIOTH

#Frame con Form Agregar Empleado
@app.route('/frameEmpleados')
def frameEmpleados():
  empleados = db['datos_generales']
  empleadosReceived = empleados.find()
  return render_template('empleados.html', empleados = empleadosReceived)

#RUTAS DE TOÑO
 
#Frame de Form Checador 
@app.route('/frameChecador', methods=['GET', 'POST'])
def frameChecador():
    if request.method == 'POST':
        # Verificar si se presionó el botón "Todos"
        todos = request.form.get('todos')
        if todos:
            # Si se presionó "Todos", devolver todos los registros
            resultados = list(db['UI'].find({}))
            return render_template('checador.html', resultados=resultados)
       
       
        tipo_busqueda = request.form.get('tipo_busqueda')
        rfc = request.form.get('rfc')
        nombre = request.form.get('nombre')
        fecha_inicio = request.form.get('fecha_inicio')
        fecha_fin = request.form.get('fecha_fin') or fecha_inicio  # Usar fecha_inicio si fecha_fin está vacía

        query = {}
        if tipo_busqueda == 'rfc' and rfc:
            query['RFC'] = rfc
        elif tipo_busqueda == 'empleado' and nombre:
            query['nombre'] = {'$regex': nombre, '$options': 'i'}
        
        if fecha_inicio:
            # Asegúrate de convertir las fechas a un formato compatible con tu base de datos si es necesario
            fecha_inicio_format = datetime.strptime(fecha_inicio, '%Y-%m-%d')
            if fecha_fin:
                fecha_fin_format = datetime.strptime(fecha_fin, '%Y-%m-%d')
            else:
                fecha_fin_format = fecha_inicio_format
            query['fecha_de_entrada'] = {'$gte': fecha_inicio_format, '$lte': fecha_fin_format}
        
        resultados = list(db['UI'].find(query))

        return render_template('checador.html', resultados=resultados)
    else:
        return render_template('checador.html')


@app.route('/obtenerRegistrosPorFecha', methods=['POST'])
def obtenerRegistrosPorFecha():
    data = request.get_json()
    fecha_inicio = data.get('fecha_inicio')
    fecha_fin = data.get('fecha_fin')

    query = {}

    # Convertir las fechas a objetos datetime solo si se han proporcionado
    if fecha_inicio:
        fecha_inicio_format = datetime.strptime(fecha_inicio, '%Y-%m-%d')
        query['fecha_de_entrada'] = {'$gte': fecha_inicio_format}
    if fecha_fin:
        fecha_fin_format = datetime.strptime(fecha_fin, '%Y-%m-%d')
        query['fecha_de_entrada'] = query.get('fecha_de_entrada', {})
        query['fecha_de_entrada']['$lte'] = fecha_fin_format

    # Filtrar los registros en la base de datos que estén dentro del rango de fechas
    # Si no se proporcionan fechas, este query devolverá todos los registros
    registros = list(db['UI'].find(query))

    # Preparar los datos para enviarlos como respuesta
    resultados = [{
        'fecha_de_entrada': registro['fecha_de_entrada'].strftime('%Y-%m-%d'),
        'nombre': registro['nombre'],
        'hora_de_entrada': registro['hora_de_entrada'],
        'tipo': registro.get('tipo_de_dia_laborable', False),  # Asegúrate de que 'tipo' es un campo válido en tus registros
        'estatus_de_entrada': registro['estatus_de_entrada']
    } for registro in registros]

    return jsonify({'resultados': resultados})


#Frame reportes con consutla

@app.route('/restaurar_registro/<rfc>', methods=['POST'])
def restaurar_registro(rfc):
    registro_modificado = db['UI'].find_one({"RFC": rfc})

    if registro_modificado and 'hora_original' in registro_modificado and 'estatus_original' in registro_modificado:
        resultado = db['UI'].update_one(
            {'RFC': rfc},
            {'$set': {
                'hora_de_entrada': registro_modificado['hora_original'],
                'estatus_de_entrada': registro_modificado['estatus_original']
            }}
        )
        if resultado.modified_count > 0:
            return jsonify({'mensaje': 'Registro restaurado exitosamente'}), 200
        else:
            return jsonify({'mensaje': 'No se pudo restaurar el registro'}), 400
    else:
        return jsonify({'mensaje': 'Registro no encontrado o falta información original'}), 404




@app.route('/frameReporteEmpleado', methods=['GET', 'POST'])
def frameReporteEmpleado():
    if request.method == 'POST':
        rfc_buscado = request.form.get('rfc')
        nombre_completo_buscado = request.form.get('nombre').strip()  # Quitamos espacios en blanco alrededor del input
        resultados = []

        if rfc_buscado:
            resultados = db['departamentos_area'].find({'RFC': rfc_buscado})
        elif nombre_completo_buscado:
            # Usar una expresión regular para permitir cualquier orden de nombre, apellido_paterno y apellido_materno
            regex = f'.*{nombre_completo_buscado}.*'
            query = {
                '$or': [
                    {'nombre': {'$regex': regex, '$options': 'i'}},
                    {'apellido_paterno': {'$regex': regex, '$options': 'i'}},
                    {'apellido_materno': {'$regex': regex, '$options': 'i'}}
                ]
            }
            resultados = db['departamentos_area'].find(query)

        resultados = list(resultados)  # Convertir el cursor a lista
        print("Resultados encontrados:", resultados)  # Depuración: imprime los resultados en la consola

        return render_template('reporte_empleado.html', resultados=resultados)
    else:
        return render_template('reporte_empleado.html')







#Esto es para mostrar en la tabla todos los empleados 
@app.route('/todosLosEmpleados')
def todosLosEmpleados():
    empleados = db['departamentos_area'].find()  # Asegúrate de que esta es la colección correcta
    lista_empleados = []

    for empleado in empleados:
        # Formatear el nombre completo del empleado
        nombre_completo = f"{empleado.get('nombre', '')} {empleado.get('apellido_paterno', '')} {empleado.get('apellido_materno', '')}".strip()
        # Asegurarse de que '_id' sea serializable
        empleado['_id'] = str(empleado['_id'])
        # Incluir el nombre completo en los datos del empleado
        empleado['nombre_completo'] = nombre_completo
        # Agregar el empleado modificado a la lista
        lista_empleados.append(empleado)

    return jsonify(lista_empleados)






#Frame para el Reporte Asistencia le modifique a esta parte 31/03/2024
@app.route('/frameReporteAsistencia', methods=['GET', 'POST'])
def frameReporteAsistencia():
    resultados = []

    if request.method == 'POST':
        rfc = request.form.get('rfc')
        nombre = request.form.get('nombre')
        fecha_inicio = request.form.get('fecha_inicio')
        fecha_fin = request.form.get('fecha_fin') or fecha_inicio

        fecha_inicio_format = datetime.strptime(fecha_inicio, '%Y-%m-%d') if fecha_inicio else None
        fecha_fin_format = datetime.strptime(fecha_fin, '%Y-%m-%d') if fecha_fin else None

        query = {}
        if rfc:
            query['RFC'] = rfc
        elif nombre:
            query['nombre'] = {'$regex': nombre, '$options': 'i'}

        if fecha_inicio_format and fecha_fin_format:
            query['fecha_de_entrada'] = {'$gte': fecha_inicio_format, '$lte': fecha_fin_format}

        registros_asistencia = db['UI'].find(query)

        for registro in registros_asistencia:
            registro['fecha_de_entrada'] = registro['fecha_de_entrada'].strftime('%Y-%m-%d')

            hora_entrada = datetime.strptime(registro['hora_de_entrada'], '%H:%M')
            hora_salida = datetime.strptime(registro['hora_de_salida'], '%H:%M')
            diferencia = hora_salida - hora_entrada
            registro['horas_trabajadas'] = round(diferencia.total_seconds() / 3600, 2)

            # Búsqueda de incidencias para cada registro basado en la coincidencia de fecha
            filtro_incidencia_exacta = {
                '$or': [{'RFC': registro.get('RFC')}, {'nombre': registro.get('nombre')}],
                'fecha_inicial': datetime.strptime(registro['fecha_de_entrada'], '%Y-%m-%d')
            }

            incidencia_exacta = db['justificaciones'].find_one(filtro_incidencia_exacta)
            registro['incidencias'] = incidencia_exacta.get('incidencia', 'Sin incidencias') if incidencia_exacta else 'Sin incidencias'

            resultados.append(registro)

    return render_template('reporte_asistencia.html', resultados=resultados)



#Esto es para mostrar todas las asistencias 
@app.route('/todosLasAsistencias')
def todosLasAsistencias():
    asistencias = db['UI'].find()  # Asegúrate de que esta es la colección correcta
    lista_asistencias = list(asistencias)  # Convertir el cursor a lista

    # Convertir los objetos ObjectId de MongoDB a string para poder serializarlos a JSON
    for asistencia in lista_asistencias:
        asistencia['_id'] = str(asistencia['_id'])

    return jsonify(lista_asistencias)




@app.route('/exportar-a-excel', methods=['POST'])
def exportar_a_excel():
    datos_json = request.get_json()
    df = DataFrame(datos_json.get('datos'), columns=['FECHA', 'RFC', 'NOMBRE', 'HORA ENTRADA', 'HORA SALIDA', 'HORAS TOTALES', 'INCIDENCIAS', 'ESTATUS'])

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, startcol=1)  # Comienza desde la columna B
        workbook = writer.book
        worksheet = writer.sheets['Sheet1']

        # Configura el ancho de las columnas
        for col in range(2, 10):
            worksheet.column_dimensions[get_column_letter(col)].width = 20

        # Combinar celdas para títulos y aplicar estilos
        worksheet.merge_cells('B1:I2')
        worksheet.merge_cells('B3:I4')
        worksheet.merge_cells('B5:I6')

        # Configura los títulos
        titles = ["TECNOLÓGICO NACIONAL DE MÉXICO CAMPUS TUXTEPEC", "RECURSOS HUMANOS", "REGISTRO DE ASISTENCIA"]
        for i, title in enumerate(titles):
            cell = worksheet.cell(row=2*i+1, column=2)
            cell.value = title
            cell.font = Font(size=14, bold=True)
            cell.alignment = Alignment(horizontal="center")

        # Configura los bordes para los títulos
        for row in range(1, 7):
            for col in range(2, 10):
                worksheet.cell(row=row, column=col).border = Border(top=Side(style='thin'), bottom=Side(style='thin'), left=Side(style='thin'), right=Side(style='thin'))

        # Configura las cabeceras de la tabla y define los bordes
        for col, header in enumerate(df.columns, start=2):
            cell = worksheet.cell(row=7, column=col)
            cell.value = header
            cell.font = Font(bold=True)
            cell.border = Border(top=Side(style='thin'), bottom=Side(style='thin'), left=Side(style='thin'), right=Side(style='thin'))
            cell.alignment = Alignment(horizontal="center")

        # Agrega los datos de la tabla y define los bordes
        for r_idx, data in enumerate(df.values, start=8):
            for c_idx, value in enumerate(data, start=2):
                cell = worksheet.cell(row=r_idx, column=c_idx)
                cell.value = value
                cell.border = Border(top=Side(style='thin'), bottom=Side(style='thin'), left=Side(style='thin'), right=Side(style='thin'))

        # Aplica el filtro a la fila de las cabeceras
        worksheet.auto_filter.ref = 'B7:I7'

    output.seek(0)
    return send_file(output, as_attachment=True, download_name="Reporte_Asistencia.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route('/exportar-a-excelem', methods=['POST'])
def exportar_a_excelem():
    datos_generales_collection = db['datos_generales']
    datos_contratacion_collection = db['datos_contratacion']

    # Obtener documentos de la colección 'datos_generales'
    documentos_generales = list(datos_generales_collection.find({}, {
        '_id': 0, 'RFC': 1, 'nombre': 1, 'apellido_paterno': 1, 'apellido_materno': 1,
        'sexo': 1, 'CURP': 1, 'fecha_de_nacimiento': 1, 'edad': 1, 'colonia': 1,
        'calle': 1, 'numero_de_casa': 1, 'ciudad': 1, 'estado': 1, 'codigo_postal': 1,
        'telefono': 1
    }))

    # Convertir a DataFrame
    df_generales = DataFrame(documentos_generales)

    # Separar registros con y sin RFC estándar
    df_srfc = df_generales[df_generales['RFC'] == 'S/RFC']
    df_generales = df_generales[df_generales['RFC'] != 'S/RFC']

    # Eliminar duplicados en registros con RFC estándar
    df_generales = df_generales.drop_duplicates(subset=['RFC'], keep='first')

    # Eliminar duplicados dentro de los registros 'S/RFC' basado en todos los campos menos el RFC
    df_srfc = df_srfc.drop_duplicates(subset=['nombre', 'apellido_paterno', 'apellido_materno', 'CURP', 'fecha_de_nacimiento', 'edad', 'colonia', 'calle', 'numero_de_casa', 'ciudad', 'estado', 'codigo_postal', 'telefono'], keep='first')

    # Reunificar los registros con y sin RFC estándar
    df_generales = pd.concat([df_srfc, df_generales], ignore_index=True)

    # Procesar la colección 'datos_contratacion' con los RFCs filtrados
    rfcs = df_generales['RFC'].tolist()
    documentos_contratacion = list(datos_contratacion_collection.find({'RFC': {'$in': rfcs}}, {
        '_id': 0, 'RFC': 1, 'departamento_o_area': 1, 'puesto': 1, 'escolaridad': 1, 'fecha_de_ingreso': 1
    }))

    df_contratacion = DataFrame(documentos_contratacion).drop_duplicates(subset=['RFC'], keep='first')
    df_final = pd.merge(df_generales, df_contratacion, on='RFC', how='left')


    
    # Configurar columnas del DataFrame final
    df_final = df_final[[
        'RFC', 'nombre', 'apellido_paterno', 'apellido_materno',
        'sexo', 'CURP', 'fecha_de_nacimiento', 'edad', 'colonia',
        'calle', 'numero_de_casa', 'ciudad', 'estado', 'codigo_postal',
        'telefono', 'departamento_o_area', 'puesto', 'escolaridad', 'fecha_de_ingreso'
    ]]
    df_final.columns = [
        'RFC', 'Nombre', 'Apellido Paterno', 'Apellido Materno',
        'Sexo', 'CURP', 'Fecha de Nacimiento', 'Edad', 'Colonia',
        'Calle', 'Número de Casa', 'Ciudad', 'Estado', 'Código Postal',
        'Teléfono', 'Departamento o Área', 'Puesto', 'Escolaridad', 'Fecha de Ingreso'
    ]

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df_final.to_excel(writer, index=False, startrow=6)
        workbook = writer.book
        worksheet = writer.sheets['Sheet1']

        for col_num in range(1, len(df_final.columns) + 1):
            worksheet.column_dimensions[get_column_letter(col_num)].width = 30

        ultima_columna = get_column_letter(len(df_final.columns))
        worksheet.merge_cells(f'A1:{ultima_columna}2')
        worksheet.merge_cells(f'A3:{ultima_columna}4')
        worksheet.merge_cells(f'A5:{ultima_columna}6')

        worksheet['A1'] = 'BUENAS TARDES'
        worksheet['A3'] = 'BUENOS DIAS'
        worksheet['A5'] = 'BUENAS NOCHES'

        for celda in ['A1', 'A3', 'A5']:
            worksheet[celda].alignment = Alignment(horizontal="center", vertical="center")
            worksheet[celda].font = Font(bold=True)

        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        for row in worksheet.iter_rows(min_row=7, max_col=len(df_final.columns), max_row=worksheet.max_row):
            for cell in row:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = thin_border

    output.seek(0)
    return send_file(output, as_attachment=True, download_name="Reporte_Datos_Generales.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")














@app.route('/frameReporteHorario', methods=['GET', 'POST'])
def frameReporteHorario():
    if request.method == 'POST':
        rfc = request.form.get('rfc')
        nombre = request.form.get('nombre')
        query = {}
        if rfc:
            query['RFC'] = int(rfc)
        if nombre:
            query['Nombre'] = {'$regex': nombre, '$options': 'i'}
        empleado = db['catalogos_horario'].find_one(query)
        resultados = []
        if empleado:
            for horario in empleado.get('Horarios', []):
                dia_info = horario.get('DIA', {})
                entrada = dia_info.get('Hora_entrada', [])[0] if dia_info.get('Hora_entrada') else 'No registrada'
                salida = dia_info.get('Hora_salida', [])[1] if dia_info.get('Hora_salida') else 'No registrada'
                resultados.append({
                    'Dia': dia_info.get('id_dia', 'No disponible'),
                    'Entrada': entrada,
                    'Salida': salida
                })
        return render_template('reporte_horario.html', resultados=resultados)
    else:
        return render_template('reporte_horario.html')

#Frame para Modificar lo Reporte Checador



@app.route('/ventana_modificar')
def ventana_modificar():
    # Recibir los parámetros de consulta
    datos = {
        'fecha': request.args.get('fecha'),
        'nombre': request.args.get('nombre'),
        'hora': request.args.get('hora'),
        'tipo': request.args.get('tipo'),
        'estatus': request.args.get('estatus')
    }
    
    return render_template('ventana_modificar.html', datos=[datos])


@app.route('/actualizar_entradas', methods=['POST'])
def actualizar_entradas():
    datos = request.form.to_dict()

    for key, value in datos.items():
        if 'hora_' in key:
            index = key.split('_')[1]
            hora = value
            estatus = datos.get(f'estatus_{index}')
            nombre_o_rfc = datos.get(f'identificador_{index}')

            registro_actual = db['UI'].find_one({'nombre': nombre_o_rfc})
            
            # Guarda los valores originales antes de actualizar
            hora_original = registro_actual['hora_de_entrada']
            estatus_original = registro_actual['estatus_de_entrada']

            # Actualiza la base de datos con los nuevos valores
            db['UI'].update_one(
                {'nombre': nombre_o_rfc},
                {'$set': {
                    'hora_de_entrada': hora, 
                    'estatus_de_entrada': estatus,
                    'hora_original': hora_original,  # Guarda los valores originales
                    'estatus_original': estatus_original
                }}
            )

    return redirect(url_for('frameChecador'))



@app.route('/actualizar_datos', methods=['POST'])
def actualizar_datos():
    datos = request.json
    identificador = datos['identificador']  # Puede ser el nombre o el RFC
    hora_de_entrada = datos['hora_de_entrada']
    estatus_de_entrada = datos['estatus_de_entrada']

    # Asumiendo que estás usando PyMongo para interactuar con MongoDB
    # Actualiza usando el RFC o el nombre como identificador. Ajusta el campo según lo que estés usando.
    resultado = db.UI.update_one(
        {"RFC": identificador},  # Cambia "RFC" por "nombre" si deseas usar el nombre como identificador
        {"$set": {"hora_de_entrada": hora_de_entrada, "estatus_de_entrada": estatus_de_entrada}}
    )

    if resultado.modified_count > 0:
        return jsonify({"mensaje": "Datos actualizados con éxito"})
    else:
        return jsonify({"mensaje": "No se pudo actualizar los datos"}), 400



@app.route('/actualizar_checador', methods=['POST'])
def actualizar_checador():
    datos = request.json['datos']
    # Aquí debes procesar 'datos', como actualizar la base de datos o la sesión.
    
    # Puedes redirigir a la vista de checador o devolver una URL para redireccionar en el cliente.
    return jsonify({'redirect_url': url_for('frameChecador')})

#Frame para el boton de Cancelar del Reporte Checador
@app.route('/ventana_checador')
def ventana_checador():
    return render_template('checador.html')

@app.route('/checador')
def checador():
    return render_template('checador.html')

#Frame con el que se despliega la tabla de los reportes
@app.route('/frameArchivos')
def frameArchivos():
  return render_template('archivos.html') 


@app.route('/frameAvisos')
def frameAvisos():
  return render_template('aviso.html') 

@app.route('/frameRed')
def frameRed():
  return render_template('red.html') 


@app.route('/buscarRfc', methods=['GET'])
def buscarRfc():
    rfc_buscado = request.args.get('rfc')  # Cambia a request.args para GET
    resultados = []
    if rfc_buscado:
        query = {'RFC': {'$regex': f'^{rfc_buscado}', '$options': 'i'}}
        resultados_cursor = db['datos_generales'].find(query, {'_id': 0, 'RFC': 1}).limit(5)
        resultados = [res['RFC'] for res in resultados_cursor]
    return jsonify(resultados)

    
@app.route('/guardarAvisoTrabajador', methods=['POST'])
def guardarAvisoTrabajador():
    rfc = request.form['rfc']
    fecha_inicio = request.form['fechaInicio']
    fecha_fin = request.form['fechaFin']
    mensaje_administrador = request.form['mensaje_administrador']

    if rfc and fecha_inicio and fecha_fin and mensaje_administrador:
        try:
            fecha_inicio_dt = datetime.strptime(fecha_inicio, '%Y-%m-%d')
            fecha_fin_dt = datetime.strptime(fecha_fin, '%Y-%m-%d')
        except ValueError:
            return "Error: Formato de fecha incorrecto. Utilice YYYY-MM-DD", 400

        aviso = {
            "rfc": rfc,
            "Fecha_inicial": fecha_inicio_dt,
            "Fecha_Final": fecha_fin_dt,
            "mensaje_administrador": mensaje_administrador
        }
        db.avisos_trabajador.insert_one(aviso)
        return redirect(url_for('confirmacion'))
    return "Error: Todos los campos son necesarios", 400

@app.route('/confirmacion')
def confirmacion():
    return render_template('aviso.html') 


@app.route('/guardarAvisoGeneral', methods=['POST'])
def guardarAvisoGeneral():
    fecha_inicio = request.form['fechaInicio']
    fecha_fin = request.form['fechaFin']
    mensaje_administrador = request.form['mensaje_administrador']

    if fecha_inicio and fecha_fin and mensaje_administrador:
        try:
            fecha_inicio_dt = datetime.strptime(fecha_inicio, '%Y-%m-%d')
            fecha_fin_dt = datetime.strptime(fecha_fin, '%Y-%m-%d')
        except ValueError:
            return "Error: Formato de fecha incorrecto. Utilice YYYY-MM-DD", 400

        aviso = {
            "Fecha_inicial": fecha_inicio_dt,
            "Fecha_Final": fecha_fin_dt,
            "mensaje_administrador": mensaje_administrador
        }
        db.avisos_generales.insert_one(aviso)
        return redirect(url_for('confirmacion'))
    return "Error: Todos los campos son necesarios", 400


@app.route('/generar_pdf', methods=['POST'])
def generar_pdf():
   # Consulta a la base de datos
    datos_generales = list(db['datos_generales'].find())
    datos_contratacion = list(db['datos_contratacion'].find())

    # Renderiza el template HTML con los datos consultados
    html = render_template('reporte_empleado_pdf.html', datos_generales=datos_generales, datos_contratacion=datos_contratacion)

    # Configura pdfkit y genera el PDF
    config = pdfkit.configuration(wkhtmltopdf=r'C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe')
    pdf = pdfkit.from_string(html, False, configuration=config)

    # Crea y devuelve la respuesta con el PDF
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=reporte_empleados.pdf'

    return response

# ---------------------------------------------------------------- RED ---------------------------------------------------------------- #

def ping(host):
    parametro = '-n' if platform.system().lower() == 'windows' else '-c'
    comando = ['ping', parametro, '2', host]
    result = subprocess.run(comando, capture_output=True, text=True)
    print(result.stdout)  # Imprime la salida para depuración
    return result.stdout


@app.route('/ping/<host>')
def ping_host(host):
    output = ping(host)
    print("Output del ping:", output)  # Agrega esto para depurar
    if 'tiempo=' in output or 'time=' in output:  # Agrega 'tiempo=' por si acaso
        return jsonify(status="success", result=output)
    else:
        return jsonify(status="failure", result=output)




@app.route('/datos-empresa')
def datos_empresa():
    # Puedes pasar variables adicionales a render_template si es necesario
    return render_template('datos_empresa.html')

@app.route('/frameusuarios')
def usuarios():
    # Puedes pasar variables adicionales a render_template si es necesario
    return render_template('usuarios.html')

@app.route('/frameinstitucion')
def institucion():
    # Puedes pasar variables adicionales a render_template si es necesario
    return render_template('institucion.html')

#TERMINAN RUTAS DE TOÑO

#PoUp Se Agrego Correctamente
@app.route('/empleadoExitoso')
def empleadoExitoso():
  return render_template('empleadoExitoso.html')

@app.route('/')
def principal():
  empleados = db['datos_generales']
  empleadosReceived = empleados.find()
  return render_template(['index.html'], empleados = empleadosReceived)

#Metodo Post
@app.route('/empleados', methods={'POST'})
def addEmpleado():
  empleados = db['datos_generales']

  rfc = request.form['rfc']
  nombre = request.form['nombre']
  apellido_p = request.form['apellido_p']
  apellido_m = request.form['apellido_m']
  fecha_de_nac = request.form['fecha_de_nac']
  edad = request.form['edad']
  sexo = request.form['sexo']
  edo_civil = request.form['edo_civil']
  curp = request.form['curp']
  telefono = request.form['telefono']
  calle = request.form['calle']
  #num_casa = request.form['num_casa']
  colonia = request.form['colonia']
  ciudad = request.form['ciudad']
  estado = request.form['estado']
  cod_pos = request.form['cod_pos']
  num_creden = request.form['num_creden']
  tipo_horario = request.form['tipo_horario']
  estatus = request.form['estatus']

#Agregar de nuevo a la lista el numero de casa
  if rfc and apellido_p and apellido_m:
    empleado = Empleado(rfc, nombre, apellido_p,apellido_m,fecha_de_nac, edad, sexo, edo_civil, curp, telefono, calle, colonia, ciudad, estado, cod_pos, num_creden, tipo_horario,estatus)
    empleados.insert_one(empleado.toDB())
    response = jsonify({
      '_id': rfc,
      'nombre' : nombre,
      'apellido_p': apellido_p,
      'apellido_m': apellido_m,
      'fecha_de_nacimiento': fecha_de_nac,
      'edad': edad,
      'sexo': sexo,
      'estado_civil': edo_civil,
      'CURP': curp,
      'telefono': telefono,
      'calle': calle,
      #'numero_de_casa': num_casa,
      'colonia': colonia,
      'ciudad': ciudad,
      'estado': estado,
      'codigo_postal': cod_pos,
      'numero_de_credencial': num_creden,
      'tipo_de_horario': tipo_horario,
      'estatus': estatus
    })
    return redirect(url_for('empleadoExitoso'))
  else:
    return notFound()

#Metodo Delete
@app.route('/delete/<string:empleado_rfc>')
def delete(empleado_rfc):
  empleados = db['datos_generales']
  empleados.delete_one({'_id': empleado_rfc})
  return redirect(url_for('principal'))

#Metodo Put
@app.route('/edit/<string:empleado_rfc>', methods=['POST'])
def edit(empleado_rfc):
  empleados = db['datos_generales']

  rfc = request.form['rfc']
  nombre = request.form['nombre']
  apellido_p = request.form['apellido_p']
  apellido_m = request.form['apellido_m']
  fecha_de_nac = request.form['fecha_de_nac']
  edad = request.form['edad']
  sexo = request.form['sexo']
  edo_civil = request.form['edo_civil']
  curp = request.form['curp']
  telefono = request.form['telefono']
  calle = request.form['calle']
  num_casa = request.form['num_casa']
  colonia = request.form['colonia']
  ciudad = request.form['ciudad']
  estado = request.form['estado']
  cod_pos = request.form['cod_pos']
  num_creden = request.form['num_creden']
  tipo_horario = request.form['tipo_horario']
  estatus = request.form['estatus']
  
  if rfc and apellido_p and apellido_m:
    empleados.update_one({'_id': empleado_rfc},{'$set': {'_id': rfc, 'nombre': nombre, 'apellido_paterno': apellido_p, 'apellido_materno': apellido_m, 'fecha_de_nacimiento': fecha_de_nac,'edad': edad, 'sexo': sexo, 'estado_civil': edo_civil, 'CURP': curp,'telefono': telefono, 'calle': calle, 'numero_de_casa': num_casa, 'colonia': colonia, 'ciudad': ciudad, 'estado': estado, 'codigo_postal': cod_pos, 'numero_de_credencial': num_creden, 'tipo_de_horario': tipo_horario, 'estatus': estatus }})
    response = jsonify({'message' : 'Empleado ' + empleado_rfc+ ' actualizado correctamente'})
    return redirect(url_for('principal'))
  else:
    return notFound
  
@app.errorhandler(404)
def notFound(error=None):
  message ={
    'message': 'No encontrado',
    'status': '404 Not Found'
  }
  response= jsonify(message)
  response.status_code = 404
  return response


if __name__ == '__main__':
  app.run(debug=True, port=5000)