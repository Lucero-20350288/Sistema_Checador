# HTML5-CHECADOR
Creación de el sistema checador para el uso en recursos humanos... HTML5 CSS JS PURO Y CRUDO
