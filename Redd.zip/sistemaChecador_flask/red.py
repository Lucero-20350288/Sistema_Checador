import platform
import subprocess

def ping(host):
    parametro = '-n' if platform.system().lower() == 'Windows' else '-c'
    comando = ['ping', parametro, '1', host]

    subprocess.call(comando)

ping('192.168.0.12')